export class Modelo {

    constructor(key : string, name : string, id : string, fipe_name : string){

    }
}
