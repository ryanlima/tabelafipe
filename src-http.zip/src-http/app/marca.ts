export class Marca {
    constructor(
        name : string,
        fipe_name : string,
        order : number,
        key : string,
        id : number
    ) {
        
    }
}
