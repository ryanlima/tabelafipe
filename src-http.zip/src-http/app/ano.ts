export class Ano {

    constructor(fipe_codigo: string , name : string, ) {
        
    }
}
