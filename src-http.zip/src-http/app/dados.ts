export class Dados {

    constructor(
        id : string, 
        ano_modelo: string , 
        marca : string , 
        name : string , 
        veiulo : string , 
        preco : string, 
        combustivel: string , 
        referencia : string, 
        fipe_codigo : string, 
        key : string
    ){}
}
